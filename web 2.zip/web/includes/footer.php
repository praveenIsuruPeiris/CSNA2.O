<div class="bottom-grid1">
			<div class="links">
				<ul class="links-unordered-list footer">
					<li class="">
						<a href="#" class="">About Us</a>
					</li>
					<li class="">
						<a href="#" class="">Privacy Policy</a>
					</li>
					<li class="">
						<a href="#" class="">Terms of Use</a>
					</li>
          <li class="">
            <a href="#" class="">&copy; Copyright <strong>VelvetTek</strong>. All Rights Reserved</a>
          </li>
				</ul>
	</div>
</div>
</html>
