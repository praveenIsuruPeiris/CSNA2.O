<?php
$title = "Details";
include "./includes/header.php";
?>
<style>
    #note{
        font-size: 25px;
        color: white;
    }
</style>
<h1 id="note">The page had the records on the details of matches that have been taken place in venues and also</h1>
    <?php
include "./includes/footer.php";
?>   