<?php
$title = "Password reset";
include "./includes/header.php";
?>
<style>
    #note{
        font-size: 25px;
        color: white;
    }
</style>
<h1 id="note">Under Construction</h1>


<?php
include "./includes/footer.php";
?>    